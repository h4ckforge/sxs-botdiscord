import discord
from discord.ext import commands
from dotenv import load_dotenv
import os

# Cargar variables de entorno desde .env
load_dotenv()
TOKEN = os.getenv('DISCORD_TOKEN')

intents = discord.Intents.all()
intents.message_content = True

bot = commands.Bot(command_prefix='!', intents=intents)

# Cargar cogs
async def load_cogs():
    await bot.load_extension('cogs.baja_agente')
    await bot.load_extension('cogs.permisos')

@bot.event
async def on_ready():
    await load_cogs()
    print(f'Bot conectado como {bot.user}')

bot.run(TOKEN)
