import discord
from discord.ext import commands

class Permisos(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command(name='permisos')
    @commands.has_permissions(administrator=True)
    async def check_permisos(self, ctx, miembro: discord.Member, canal: discord.TextChannel = None):
        """
        Uso: !permisos @usuario #canal
        Si no se especifica canal, usa el canal actual.
        """
        canal = canal or ctx.channel

        permisos = canal.permissions_for(miembro)
        roles = [r.name for r in miembro.roles if r.name != "@everyone"]

        permisos_relevantes = {
            "Ver canal": permisos.view_channel,
            "Enviar mensajes": permisos.send_messages,
            "Leer historial": permisos.read_message_history,
            "Adjuntar archivos": permisos.attach_files,
            "Añadir reacciones": permisos.add_reactions,
            "Conectarse a voz": permisos.connect,
            "Hablar en voz": permisos.speak,
            "Usar comandos de apps": permisos.use_application_commands,
            "Mencionar @everyone": permisos.mention_everyone,
            "Gestionar mensajes": permisos.manage_messages,
            "Gestionar canal": permisos.manage_channels,
            "Gestionar roles": permisos.manage_roles,
        }

        lineas_permisos = []
        for nombre, valor in permisos_relevantes.items():
            emoji = "✅" if valor else "❌"
            lineas_permisos.append(f"{emoji} {nombre}")

        embed = discord.Embed(
            title="Diagnóstico de permisos",
            color=discord.Color.red() if not permisos.view_channel else discord.Color.green()
        )
        embed.add_field(name="Usuario", value=miembro.mention, inline=True)
        embed.add_field(name="Canal", value=canal.mention, inline=True)
        embed.add_field(name="Categoría", value=canal.category.name if canal.category else "Sin categoría", inline=True)
        embed.add_field(name="Roles", value=", ".join(roles) if roles else "Sin roles", inline=False)
        embed.add_field(name="Permisos efectivos", value="\n".join(lineas_permisos), inline=False)

        await ctx.send(embed=embed)

async def setup(bot):
    await bot.add_cog(Permisos(bot))
